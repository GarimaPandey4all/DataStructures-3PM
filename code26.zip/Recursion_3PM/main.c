#include <stdio.h>
#include <stdlib.h>

int main()
{
    int k;

    k = func(3);

    printf("%d", k);

    return 0;
}

int func(int a)
{
    if(a==1) //base recursion
    {
        return a;
    }

    s = a+func(a-1); //recursion call
    return s;
}
