#include <stdio.h>
#include <stdlib.h>

//Defining a node (Data Type)

struct node
{
    struct node *prev;
    int info;
    struct node *next;
};

struct node *START = NULL;

struct node *createNode()
{
    struct node *n;

    n = (struct node *)malloc(sizeof(struct node));

    return(n);
};

//Insert at Start in a list
void insertnodeAtStart()
{
    struct node *temp;

    temp = createNode();

    temp->prev = NULL; //As node insert at start position in a list

    printf("Enter a number:");
    scanf("%d", &temp->info);

    temp->next = START;

    START = temp;

}

int main()
{

    int choice;

    while(1)
    {
        printf("\n\n1. Add value at Start in a list.");
        printf("\n5. Exit.");
        printf("\n\nEnter your Choice:");
        scanf("%d", &choice);

        switch(choice)
        {
        case 1:
            insertnodeAtStart();
            break;

        case 5:
            exit(0);

        default:
            printf("Invalid Choice.");
        }
    }

    return 0;
}
