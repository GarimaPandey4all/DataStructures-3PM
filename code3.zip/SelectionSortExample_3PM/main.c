#include <stdio.h>
#include <stdlib.h>

int main()
{
    int i, j, n, temp, array[20], min;

    printf("Enter number of elements:");
    scanf("%d", &n);

    printf("Enter %d Integers:", n);
    for(i=0; i<n; i++)
    {
        scanf("%d", &array[i]); // 7, 3, 5, 4, 2
        //2, 3, 5, 4, 7
        //2, 3, 4, 5, 7
    }

    for(i=0; i<n-1; i++)
    {
        min = i;
        for(j=i+1; j<n; j++)
        {
           if(array[j]<array[min]) //7<5 //min = 3
           {
               min = j;
           }
        }
        //swapping

        temp = array[i];
        array[i] = array[min];
        array[min] = temp;

    }

    printf("Selection Sorted List is:");
    for(i=0; i<n; i++)
    {
        printf("%d ", array[i]);
    }

    return 0;
}
