#include <stdio.h>
#include <stdlib.h>

struct stack
{
    int info;
    struct stack *link;
};

struct stack *Top = NULL;

struct stack *createStack()
{
    struct stack *n;

    n = (struct stack *)malloc(sizeof(struct stack));

    return(n);
};

//Insert/Push in a Stack
void push()
{
    struct stack *temp;

    temp = createStack();

    printf("Enter a number:");
    scanf("%d", &temp->info);

    temp->link = Top;

    Top = temp;
}

//Delete/Pop from a stack
int pop()
{
    struct stack *t1;

    if(Top == NULL)
    {
        printf("Stack is Empty. Underflow.");
        return(0);
    }
    else
    {
        t1 = Top;
        Top = Top->link;
        free(t1);
        return(1);
    }
}

//Traverse/Visit the Stack
int display()
{
    struct stack *T;

    if(Top == NULL)
    {
        printf("Stack is Empty. Underflow");
        return(0);
    }
    else
    {
        T = Top;
        while(T != NULL)
        {
            printf("%d  ", T->info);
            T = T->link;
        }
        return(1);
    }
}


int main()
{
    int choice;

    while(1)
    {
        printf("\n\n1. Push.");
        printf("\n2. Pop.");
        printf("\n3. Display.");
        printf("\n4. Exit.");
        printf("\n\nEnter your Choice:");
        scanf("%d", &choice);

        switch(choice)
        {
        case 1:
            push();
            break;

        case 2:
            pop();
            break;

        case 3:
            display();
            break;

        case 4:
            exit(0);

        default:
            printf("Invalid Choice.");
        }
    }

    return 0;
}
