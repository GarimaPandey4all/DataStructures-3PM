#include <stdio.h>
#include <stdlib.h>

int main()
{
    int matrix[10][10], i, j, rows, columns;

    printf("Enter number of rows:");
    scanf("%d", &rows);

    printf("Enter number of columns:");
    scanf("%d", &columns);

    printf("Enter %d Integers:", rows * columns);
    for(i=0; i<rows; i++)
    {
        for(j=0; j<columns; j++)
        {
            scanf("%d", &matrix[i][j]);
        }
    }

    printf("Matrix is:\n");
    for(i=0; i<rows; i++)
    {
        for(j=0; j<columns; j++)
        {
            printf("%d\t", matrix[i][j]);
        }
        printf("\n");
    }

    //Principal Diagonal Matrix

    printf("Principal Diagonal Matrix is:\n");
    for(i=0; i<rows; i++)
    {
        for(j=0; j<columns; j++)
        {
            if(i == j)
                printf("%d\t", matrix[i][j]);
        }
    }



    return 0;
}
