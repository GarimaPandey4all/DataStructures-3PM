#include <stdio.h>
#include <stdlib.h>

//Defining a Node(Data Type)

struct node
{
    struct node *prev;
    int info;
    struct node *next;
};

struct node *START = NULL;

struct node *createNode()
{
    struct node *n;

    n = (struct node *)malloc(sizeof(struct node));

    return(n);
};

//Search in a list
struct node *searchNode()
{
    struct node *temp;
    int search;

    if(START == NULL)
        return(NULL); //List is Empty.
    else
    {
        printf("Enter any value to be search:");
        scanf("%d", &search);

        temp = START;
        while(temp->next != NULL)
        {
            if(temp->info == search)
            {
                return(temp); //return value that is found in a list
            }
            temp = temp->next;
        }
        return(NULL); //Invalid Search
    }
};

//Insert node in a list at start position

void insertNodeAtStart()
{
    struct node *temp;

    temp = createNode();

    temp->prev = NULL; // As node insert at start

    printf("Enter a number:");
    scanf("%d", &temp->info);

    temp->next = START;

    START = temp;
}

//Insert node in a list at Last position
void insertNodeAtLast()
{
    struct node *temp, *temp1;

    temp = createNode();

    printf("Enter a number:");
    scanf("%d", &temp->info);

    temp->next = NULL;
    if(START == NULL)
    {
        temp->prev = NULL;
        START = temp;
    }
    else
    {
        temp1 = START;
        while(temp1->next != NULL)
        {
            temp1 = temp1->next;
        }
        temp->prev = temp1;
        temp1->next = temp;
    }
}

//insert node after a particular node in a list
void insertAfterNode()
{
    struct node *ptr, *temp;

    ptr = searchNode();

    if(ptr == NULL)
        printf("Invalid Insertion. List is Empty.");
    else
    {
        temp = createNode();

        printf("Enter a number:");
        scanf("%d", &temp->info);

        temp->prev = ptr;
        temp->next = ptr->next;

        if(ptr->next != NULL)
            ptr->next->prev = temp;

        ptr->next = temp;
    }
}

//Delete first node from a list
void deleteFirstNode()
{
    struct node *t;

    if(START == NULL)
        printf("List is Empty.");
    else{
        t = START;
        START = START->next;
        START->prev = NULL;
        free(t);
    }
}

//Delete last node from a list
int deleteLastNode()
{
    struct node *t;

    if(START == NULL)
    {
        printf("List is Empty.");
        return(0);
    }
    else
    {
        t = START;
        while(t->next != NULL)
        {
            t = t->next;
        }
        if(START->next == NULL)
            START = NULL;
        else
        {
            t->prev->next = NULL;
        }
        free(t);
        return(1);
    }
}

//Delete any intermediate node from a list
int deleteIntermediateNode()
{
    struct node *ptr;

    //ptr = searchNode();

    if(START == NULL)
    {
        printf("Invalid Search. List is Empty.");
        return(0);
    }
    else
    {
        ptr = searchNode();

    if(ptr->prev == NULL)
    {
        START = ptr->next;
        free(ptr);
        return(1);
    }

    if(ptr->next == NULL)
    {
        ptr->prev->next = ptr->next;
        free(ptr);
        return(1);
    }


    ptr->prev->next = ptr->next;
    ptr->next->prev = ptr->prev;
    free(ptr);
    return(1);
    }
}

//View List in a forward Direction
void viewList()
{
    struct node *T;

    if(START == NULL)
        printf("List is Empty.");
    else
    {
        T = START;
        while(T != NULL)
        {
            printf("%d ", T->info);
            T = T->next;
        }
    }
}

//Traverse only first node
int getFirst()
{
    if(START == NULL)
    {
        printf("List is Empty.");
        return(0);
    }
    else
    {
        printf("First Node is:%d", START->info);
        return(1);
    }
}

//Traverse only last node
int getLast()
{
    struct node *t;

    if(START == NULL)
    {
        printf("List is Empty.");
        return(0);
    }
    else
    {
        t = START;

        while(t->next != NULL)
        {
            t = t->next;
        }
        printf("Last node is:%d", t->info);
        return(1);
    }
}

int main()
{
    int choice;

    while(1)
    {
        printf("\n\n1. Add value in a list at start position.");
        printf("\n2. Add value in a list at last position.");
        printf("\n3. Add value after a particular node in a list.");
        printf("\n4. Delete first node from a list.");
        printf("\n5. Delete last node from a list.");
        printf("\n6. Delete any Intermediate node from a list.");
        printf("\n7. View List.");
        printf("\n8. Visit only first node.");
        printf("\n9. Visit only alst node.");
        printf("\n10. Exit.");
        printf("\n\nEnter your choice:");
        scanf("%d", &choice);

        switch(choice)
        {
        case 1:
            insertNodeAtStart();
            break;

        case 2:
            insertNodeAtLast();
            break;

        case 3:
            insertAfterNode();
            break;

        case 4:
            deleteFirstNode();
            break;

        case 5:
            deleteLastNode();
            break;

        case 6:
            deleteIntermediateNode();
            break;

        case 7:
            viewList();
            break;

        case 8:
            getFirst();
            break;

        case 9:
            getLast();
            break;

        case 10:
            exit(0);

        default:
            printf("Invalid Case.");
        }
    }

    return 0;
}

