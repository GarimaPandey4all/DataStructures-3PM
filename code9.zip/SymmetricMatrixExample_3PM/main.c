#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a[10][10], b[10][10], i, j, rows, columns, count=1;

    printf("Enter number of rows:");
    scanf("%d", &rows);

    printf("Enter number of columns:");
    scanf("%d", &columns);

    printf("Enter %d Integers:", rows * columns);
    for(i=0; i<rows; i++)
    {
        for(j=0; j<columns; j++)
        {
            scanf("%d", &a[i][j]);
        }
    }

    printf("Values in Original Matrix:\n");
    for(i=0; i<rows; i++)
    {
        for(j=0; j<columns; j++)
        {
            printf("%d\t", a[i][j]);
        }
        printf("\n");
    }

    //Transpose of a Matrix

    for(i=0; i<rows; i++)
    {
        for(j=0; j<columns; j++)
        {
            b[j][i] = a[i][j];
        }
    }

    printf("Values in Transposed Matrix:\n");
    for(i=0; i<rows; i++)
    {
        for(j=0; j<columns; j++)
        {
            printf("%d\t", b[i][j]);
        }
        printf("\n");
    }

    //Check for Symmetric Matrix
    for(i=0; i<rows; i++)
    {
        for(j=0; j<columns; j++)
        {
            if(a[i][j] != b[i][j])
            {
                ++count;
                break;
            }
        }
    }

    if(count ==1)
        printf("After transpose matrix is Symmetric Matrix.");

    else
        printf("After transpose matrix is not symmetric Matrix.");

    return 0;
}
