#include <stdio.h>
#include <stdlib.h>

struct node
{
    int info;
    struct node *link;
};

struct node *last = NULL;

struct node *createNode()
{
    struct node *n;

    n = (struct node *)malloc(sizeof(struct node));

    return(n);
};

//Insert node in a Empty List
void insertToEmpty()
{
    struct node *temp;

    temp = createNode();

    printf("Enter a number:");
    scanf("%d", &temp->info);

    last = temp;
    last->link = last;
}

//Insert node at beg in a list
void insertATStart()
{
    struct node *temp;

    temp = createNode();

    printf("Enter a number:");
    scanf("%d", &temp->info);

    temp->link = last->link;
    last->link = temp;
}

//Insert node at the end in a list
void insertAtEnd()
{
    struct node *temp;

    temp = createNode();

    printf("Enter a number:");
    scanf("%d", &temp->info);

    temp->link = last->link;
    last->link = temp;

    last = temp; //last node in a list
}

//Insert node after a particular node in a list
int insertAfterNode()
{
    struct node *temp, *ptr;
    int search;

    if(last == NULL)
    {
        printf("List is Empty.");
        return(0);
    }

    printf("Enter value to be search:");
    scanf("%d", &search);

    ptr = last->link;

    do
    {
        if(ptr->info == search)
        {
            temp = createNode();

            printf("Enter a number:");
            scanf("%d", &temp->info);

            temp->link = ptr->link;
            ptr->link = temp;

            if(ptr == last)
                last = temp;

            return(1);
        }
        ptr = ptr->link;
    }while(ptr != last->link);

printf("%d is not found in a list.", search);
return(0);
}

//Delete node from a list
int deleteNode()
{
    struct node *ptr, *t;
    int search;

    if(last == NULL)
    {
        printf("List is Empty.");
        return(0);
    }

    printf("Enter any value to be search:");
    scanf("%d", &search);

    if(last == last->link && last->info == search)
    {
        t = last;
        last = NULL;
        free(t);
        return(1);
    }

    if(last->link->info == search)
    {
        t = last->link;
        last->link = t->link;
        free(t);
        return(1);
    }

    ptr = last->link;

    while(ptr->link != last)
    {
        if(ptr->link->info == search)
        {
            t = ptr->link;
            ptr->link = t->link;
            free(t);
            return(1);
        }
    }


}


int main()
{

    return 0;
}
