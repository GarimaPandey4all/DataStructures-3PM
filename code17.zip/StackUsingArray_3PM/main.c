#include <stdio.h>
#include <stdlib.h>
#define MAX 10

//Global Variables
int i, top = -1, stack[MAX];

//Insert in a stack: push()
void push()
{
    int value;

    if(top == MAX-1)
        printf("Stack is Overflow.");
    else
    {
        printf("Enter the number to be insert:");
        scanf("%d", &value);

        ++top;
        stack[top] = value;
    }
}

//Delete from a stack: Pop()
void pop()
{
    int value;

    if(top == -1)
    {
        printf("Stack is Underflow.");
    }
    else
    {
        value = stack[top];
        printf("The deleted item is: %d", stack[top]);

        --top;
    }
}

//Display stack
void display()
{
    if(top == -1)
    {
        printf("Stack is Underflow.");
    }
    if(top >= 0)
    {
        printf("The elements of the stack are:\n");
        for(i=top; i>=0; i--)
        {
            printf("%d  ", stack[i]);
        }
    }
}

int main()
{
    int choice;

    while(1)
    {
        printf("\n\n1. Push in a Stack.");
        printf("\n2. Pop from a Stack.");
        printf("\n3. Display Stack.");
        printf("\n4. Exit.");
        printf("\n\nEnter your choice:");
        scanf("%d", &choice);

        switch(choice)
        {
        case 1:
            push();
            break;

        case 2:
            pop();
            break;

        case 3:
            display();
            break;

        case 4:
            exit(0);

        default:
            printf("Invalid Choice");
        }
    }
    return 0;
}
