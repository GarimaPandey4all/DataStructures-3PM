#include <stdio.h>
#include <stdlib.h>

struct node
{
    char info;
    struct node *left;
    struct node *right;
};

struct node *createNode(char value)
{
    struct node *n;

    n = (struct node *)malloc(sizeof(struct node));

    n->info = value;
    n->left = NULL;
    n->right = NULL;

    return(n);
};

//Preorder Traversal

void preorder(struct node *root)
{
    if(root != NULL)
    {
        printf("%c ", root->info);
        preorder(root->left); //recursive
        preorder(root->right);
    }
}

//Inorder Traversal

void inorder(struct node *root)
{
    if(root != NULL)
    {
        inorder(root->left); //recursive
        printf("%c ", root->info);
        inorder(root->right);
    }
}

//postorder Traversal

void postorder(struct node *root)
{
    if(root != NULL)
    {
        postorder(root->left); //recursive
        postorder(root->right);
        printf("%c ", root->info);
    }
}

//Insert at left
struct node *insertLeft(struct node *root, char value)
{
    root->left = createNode(value);
    return root->left;
};

//Insert at right
struct node *insertRight(struct node *root, char value)
{
    root->right = createNode(value);
    return root->right;
};

int main()
{
    struct node *root = createNode('a');

    insertLeft(root, 'c');
    insertRight(root, 'b');

    insertLeft(root->left, 'd');
    insertRight(root->left,'e');

    insertLeft(root->right, 'f');
    insertRight(root->right,'g');

    printf("Preorder Traversal:\n");
    preorder(root);

    printf("\nInorder Traversal:\n");
    inorder(root);

    printf("\nPostorder Traversal:\n");
    postorder(root);

    return 0;
}
