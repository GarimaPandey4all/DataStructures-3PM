#include <stdio.h>
#include <stdlib.h>

int main()
{
    int matrix[10][10], i, j, rows, columns, Total=0;

    printf("Enter number of rows:");
    scanf("%d", &rows);

    printf("Enter number of columns:");
    scanf("%d", &columns);

    printf("Enter %d Integers:", rows*columns);
    for(i=0; i<rows; i++)
    {
        for(j=0; j<columns; j++)
        {
            scanf("%d", &matrix[i][j]);
        }
    }

    printf("Matrix is:\n");
    for(i=0; i<rows; i++)
    {
        for(j=0; j<columns; j++)
        {
            printf("%d\t", matrix[i][j]);
        }
        printf("\n");
    }

    for(i=0; i<rows; i++)
    {
        for(j=0; j<columns; j++)
        {
            if(matrix[i][j]==0)
            {
                ++Total;
            }
        }
    }

    if(Total> (rows * columns)/2)
        printf("Matrix is Sparse Matrix.");
    else
        printf("Matrix is not sparse matrix.");

    return 0;
}
