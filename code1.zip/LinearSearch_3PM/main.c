#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n, i, search, array[30];

    printf("Enter number of elements that you want to add in a list.");
    scanf("%d", &n);

    printf("Enter %d Integers:", n);

    for(i=0; i<n; i++)
    {
        scanf("%d", &array[i]);
    }

    printf("Enter element that want to search:");
    scanf("%d", &search);

    for(i=0; i<n; i++)
    {
        if(array[i]==search)
        {
            printf("%d element found at location %d.", search, i+1);
            break;
        }
    }

    if(i==n)
    {
        printf("%d element isn't found in the list.", search);
    }

    return 0;
}
