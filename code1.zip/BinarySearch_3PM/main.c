#include <stdio.h>
#include <stdlib.h>

int main()
{
    int i, first, last, middle, n, search, array[30];

    printf("Enter number of elements:");
    scanf("%d", &n);

    printf("Enter %d Integers:", n);

    for(i=0; i<n; i++)
    {
        scanf("%d", &array[i]);
    }

    printf("Enter number to search:");
    scanf("%d", &search);

    first = 0;
    last = n-1;

    middle = (first + last)/2;

    while(first <= last)
    {
        if(array[middle] < search )
        {
            first = middle + 1;
        }
        else if(array[middle] == search)
        {
            printf("%d element found at location %d.", search, middle + 1);
            break;
        }
        else
        {
            last = middle - 1;
        }

        middle = (first+last)/2;

    }

    if(first>last)
    {
        printf("%d not found in the list", search);
    }

    return 0;
}
