#include<stdio.h>

void quicksort(int number[25],int first,int last) //function definition
{
   int i, j, pivot, temp;

   if(first<last)
    {
      pivot=first;
      i=first;
      j=last;

      while(i<j){
         while(number[i]<=number[pivot] && i<last)
            i++; // 5

         while(number[j]>number[pivot])
            j--; // 4

         if(i<j) //(5<4)
        {
            temp=number[i];
            number[i]=number[j];
            number[j]=temp;
         }
      }

    //swapping of pivot number
      temp = number[pivot];
      number[pivot] = number[j];
      number[j]=temp;

      //recursively sort the sub-arrays
      quicksort(number,first,j-1); //Left sub-array sort
      quicksort(number,j+1,last); //right sub-array sort

   }
}

int main()
{

   int i, n, number[25];

   printf("Enter Number of Elements: ");
   scanf("%d",&n);

   printf("Enter %d elements: ", n);
   for(i=0;i<n;i++)
      scanf("%d",&number[i]);

   quicksort(number,0,n-1); //function calling

   printf("Order of Sorted elements: ");
   for(i=0;i<n;i++)
      printf(" %d",number[i]);

   return 0;
}
