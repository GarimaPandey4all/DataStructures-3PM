#include <stdio.h>
#include <stdlib.h>

//Defining a node (Data Type)

struct node
{
    struct node *prev;
    int info;
    struct node *next;
};

struct node *START = NULL;

struct node *createNode()
{
    struct node *n;

    n = (struct node *)malloc(sizeof(struct node));

    return(n);
};

//Search node
struct node *searchNode()
{
    struct  node *temp;
    int search;

    if(START == NULL)
        return(NULL); //List is Empty.

    else
    {
        printf("Enter a number to be search:");
        scanf("%d", &search);

        temp = START;

        while(temp != NULL)
        {
            if(temp->info == search)
            {
                return(temp); //Node found in a list
            }

            temp = temp->next;
        }
        return(NULL); //Invalid Search in a list
    }
};

//Insert at Start in a list
void insertnodeAtStart()
{
    struct node *temp;

    temp = createNode();

    temp->prev = NULL; //As node insert at start position in a list

    printf("Enter a number:");
    scanf("%d", &temp->info);

    temp->next = START;

    START = temp;
}

//Insert at Last in a list
void insertnodeAtLast()
{
    struct node *temp, *temp1;

    temp = createNode(); //new node

    printf("Enter a number:");
    scanf("%d", &temp->info);

    temp->next = NULL; //assign NULL to temp->next

    if(START == NULL)
    {
        temp->prev = NULL;
        START = temp; //new node assign to START pointer
    }
    else
    {
        temp1 = START;

        while(temp1->next != NULL)
        {
            temp1 = temp1->next;
        }

        temp->prev = temp1;
        temp1->next = temp;
    }

}

//insert after a particular node in a list
void insertAfterNode()
{
    struct node *temp, *ptr;

    ptr = searchNode();

    if(ptr == NULL)
        printf("Invalid Insertion. List is Empty.");

    else
    {
       temp = createNode();

       printf("Enter a number:");
       scanf("%d", &temp->info);

       temp->prev = ptr;
       temp->next = ptr->next;

       if(ptr->next != NULL)
        ptr->next->prev = temp;

       ptr->next = temp;
    }
}


//View list in a forward direction
void viewList()
{
    struct node *T;

    if(START == NULL)
        printf("List is Empty.");
    else
    {
        T = START;
        while(T != NULL)
        {
            printf("%d ", T->info);
            T = T->next;
        }
    }
}

int main()
{

    int choice;

    while(1)
    {
        printf("\n\n1. Add value at Start in a list.");
        printf("\n2. Add value at Last in a list.");
        printf("\n3. Add value after a particular node in a list.");
        printf("\n4. View List in a Forward Direction.");
        printf("\n5. Exit.");
        printf("\n\nEnter your Choice:");
        scanf("%d", &choice);

        switch(choice)
        {
        case 1:
            insertnodeAtStart();
            break;

        case 2:
            insertnodeAtLast();
            break;

        case 3:
            insertAfterNode();
            break;

        case 4:
            viewList();
            break;

        case 5:
            exit(0);

        default:
            printf("Invalid Choice.");
        }
    }

    return 0;
}
