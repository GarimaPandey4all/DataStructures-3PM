#include <stdio.h>
#include <stdlib.h>

struct BSTNode
{
    int info;
    struct BSTNode *left;
    struct BSTNode *right;
};

struct BSTNode *createNode(int value)
{
    struct BSTNode *n;

    n = (struct BSTNode *)malloc(sizeof(struct BSTNode));

    n->info = value;
    n->left = NULL;
    n->right = NULL;

    return(n);
};

struct BSTNode *insert(struct BSTNode *root, int value)
{
    if(root == NULL)
        return createNode(value);
    if(value < root->info)
        root->left = insert(root->left, value);
    else if(value > root->info)
        root->right = insert(root->right, value);
    return root;
};

void inorder(struct BSTNode *root)
{
    if(root != NULL)
    {
        inorder(root->left);
        printf("%d\t", root->info);
        inorder(root->right);
    }
}

int main()
{
    struct BSTNode *root = NULL;

    root = insert(root, 8);

    insert(root, 3);
    insert(root, 1);
    insert(root, 4);
    insert(root, 7);
    insert(root, 6);
    insert(root, 10);
    insert(root, 14);
    insert(root, 4);

    inorder(root);

    return 0;
}
