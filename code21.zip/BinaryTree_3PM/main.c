#include <stdio.h>
#include <stdlib.h>

struct node
{
    int info;
    struct node *left;
    struct node *right;
};

struct node *createNode(int value)
{
    struct node *n;

    n = (struct node *)malloc(sizeof(struct node));

    n->info = value;
    n->left = NULL;
    n->right = NULL;

    return(n);
};

//Preorder Traversal

void preorder(struct node *root)
{
    if(root != NULL)
    {
        printf("%d ", root->info);
        preorder(root->left); //recursive
        preorder(root->right);
    }
}

//Inorder Traversal

void inorder(struct node *root)
{
    if(root != NULL)
    {
        inorder(root->left); //recursive
        printf("%d ", root->info);
        inorder(root->right);
    }
}

//postorder Traversal

void postorder(struct node *root)
{
    if(root != NULL)
    {
        postorder(root->left); //recursive
        postorder(root->right);
        printf("%d ", root->info);
    }
}

int main()
{
    struct node *root = createNode(1);

    root->left = createNode(2);

    root->right = createNode(3);

    root->left->left = createNode(4);

    root->left->right = createNode(5);

    printf("Preorder Traversal:\n");
    preorder(root);

    printf("\nInorder Traversal:\n");
    inorder(root);

    printf("\nPostorder Traversal:\n");
    postorder(root);

    return 0;
}
