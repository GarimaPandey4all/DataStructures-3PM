#include <stdio.h>
#include <stdlib.h>

struct node
{
    int info;
    struct node *left;
    struct node *right;
};

struct node *createNode(int value)
{
    struct node *n;

    n = (struct node *)malloc(sizeof(struct node));

    n->info = value;
    n->left = NULL;
    n->right = NULL;

    return(n);
};

//Preorder Traversal

void preorder(struct node *root)
{
    if(root != NULL)
    {
        printf("%d ", root->info);
        preorder(root->left); //recursive
        preorder(root->right);
    }
}

//Inorder Traversal

void inorder(struct node *root)
{
    if(root != NULL)
    {
        inorder(root->left); //recursive
        printf("%d ", root->info);
        inorder(root->right);
    }
}

//postorder Traversal

void postorder(struct node *root)
{
    if(root != NULL)
    {
        postorder(root->left); //recursive
        postorder(root->right);
        printf("%d ", root->info);
    }
}

//Insert at left
struct node *insertLeft(struct node *root, int value)
{
    root->left = createNode(value);
    return root->left;
};

//Insert at right
struct node *insertRight(struct node *root, int value)
{
    root->right = createNode(value);
    return root->right;
};

int main()
{
    struct node *root = createNode(1);

    insertLeft(root, 12);
    insertRight(root, 9);

    insertLeft(root->left, 5);
    insertRight(root->left,6);

    insertLeft(root->right, 3);
    insertRight(root->right,7);

    printf("Preorder Traversal:\n");
    preorder(root);

    printf("\nInorder Traversal:\n");
    inorder(root);

    printf("\nPostorder Traversal:\n");
    postorder(root);

    return 0;
}
