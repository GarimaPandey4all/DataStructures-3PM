#include <stdio.h>
#include <stdlib.h>

struct queue
{
    int info;
    struct queue *link;
};

struct queue *front = NULL;

struct queue *rear = NULL;

struct queue *createQueue()
{
    struct queue *n;

    n = (struct queue *)malloc(sizeof(struct queue));

    return(n);
};

void enqueue()
{
    struct queue *temp;

    temp = createQueue();

    printf("Enter a value:");
    scanf("%d", &temp->info);

    temp->link = NULL;

    if(front == NULL)
        front = rear = temp;
    else
    {
        rear->link = temp;
        rear = temp;
    }
}

void dequeue()
{
    struct queue *temp;

    if(front == NULL)
        printf("Queue is Empty.");
    else
    {
        temp = front;

        front = front->link;

        printf("Deleted value is:%d.", temp->info);
        free(temp);
    }
}

void display()
{
    struct queue *temp;

    if(front == NULL)
        printf("Queue is Empty.");
    else
    {
        temp = front;

        while(temp != NULL)
        {
            printf("%d  ", temp->info);
            temp = temp->link;
        }
    }
}

int main()
{
    int choice;

    while(1)
    {
        printf("\n\n1. Enqueue.");
        printf("\n2. Dequeue.");
        printf("\n3. Display.");
        printf("\n4. Exit.");
        printf("\n\nEnter your choice:");
        scanf("%d", &choice);

        switch(choice)
        {
        case 1:
            enqueue();
            break;

        case 2:
            dequeue();
            break;

        case 3:
            display();
            break;

        case 4:
            exit(0);

        default:
            printf("Invalid Choice.");
        }
    }
    return 0;
}
