#include <stdio.h>
#include <stdlib.h>
#define SIZE 5

//Global Variables

int items[SIZE], front = -1, rear = -1;

//Insert/Enqueue in a Queue
void enqueue()
{
    int value;

    if(rear == SIZE-1)
        printf("Queue is Full.");
    else
    {
        printf("Enter a value:");;
        scanf("%d", &value);

        if(front == -1)
            front = 0;

        rear++;
        items[rear] = value;
    }
}

//Delete/Dequeue from a queue
void dequeue()
{
    if(front == -1)
        printf("Queue is Empty.");
    else
    {
        printf("Deleted value is:%d.", items[front]);
        front++;

        if(front > rear)
            front = rear = -1;
    }
}

//Display Queue
void display()
{
    if(rear == -1)
        printf("Queue is Empty.");
    else
    {
        int i;
        printf("Elements in queue are:\n");
        for(i = front; i<=rear; i++)
        {
            printf("%d  ", items[i]);
        }
        printf("\n");
    }
}

int main()
{
    int choice;

    while(1)
    {
        printf("\n\n1. Enqueue.");
        printf("\n2. Dequeue.");
        printf("\n3. Display.");
        printf("\n4. Exit.");
        printf("\n\nEnter your choice:");
        scanf("%d", &choice);

        switch(choice)
        {
        case 1:
            enqueue();
            break;

        case 2:
            dequeue();
            break;

        case 3:
            display();
            break;

        case 4:
            exit(0);

        default:
            printf("Invalid Choice.");
        }
    }
    return 0;
}
