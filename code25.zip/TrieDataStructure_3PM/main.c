#include <stdio.h>
#include <stdlib.h>
#define N 26

struct TrieNode
{
    char data;
    struct TrieNode *children[N];
    int is_leaf;
};

struct TrieNode *createTrieNode(char data)
{
    struct TrieNode *n;

    n = (struct TrieNode *)malloc(sizeof(struct TrieNode));

    for(int i=0; i<N; i++)
    {
        n->children[i] = NULL;
    }

    n->is_leaf = 0;
    n->data = data;

    return n;
};

//Insert in a Trie
struct TrieNode *insertTrie(struct TrieNode *root, char *word)
{
    struct TrieNode *temp;

    temp = root;

    for(int i=0; word[i] != '\0'; i++)
    {
        int index = (int)word[i] -'a';

        if(temp->children[index] == NULL)
        {
            temp->children[index] = createTrieNode(word[i]);
        }

        temp = temp->children[index];
    }

    temp->is_leaf = 1;
    return root;
};

//Search in a Trie
int searchTrie(struct TrieNode *root, char *word)
{
    struct TrieNode *temp = root;

    for(int i=0; word[i] != '\0'; i++)
    {
        int position = word[i] - 'a';

        if(temp->children[position] == NULL)
        {
            return 0;
        }

        temp = temp->children[position];
    }

    if(temp != NULL && temp->is_leaf == 1)
    {
        return 1;
    }

    return 0;
}

void deleteTrie(struct TrieNode *n)
{
    for(int i=0; i<N; i++)
    {
        if(n->children[i] != NULL)
        deleteTrie(n->children[i]);

        else
        continue;

    }
    free(n);
}

void displayTrie(struct TrieNode *root)
{
    if(!root)
    {
        return;
    }

    struct TrieNode *temp = root;

    printf("%c  ", temp->data);

    for(int i=0; i<N; i++)
    {
        displayTrie(temp->children[i]);
    }
}

void printSearch(struct TrieNode *root, char *word)
{
    printf("\nSearching for %s:", word);

    if(searchTrie(root, word) == 0)
        printf("\nNot Found.");
    else
        printf("\nFound.");
}

int main()
{
    struct TrieNode *root;

    root = createTrieNode('\0');

    root = insertTrie(root, "hello");
    root = insertTrie(root, "hi");

    printSearch(root, "hi");
    printSearch(root, "hello");
    printSearch(root, "he");

    displayTrie(root);

    deleteTrie(root);

    return 0;
}
