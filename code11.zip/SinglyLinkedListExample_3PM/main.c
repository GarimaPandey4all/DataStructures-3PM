#include <stdio.h>
#include <stdlib.h>

//Defining a node (data type)

struct node
{
    int info;
    struct node *link;
};

//Start/head pointer

struct node *START = NULL; //list is empty

struct node *createNode()
{
    struct node *n;
    n = (struct node *)malloc(sizeof(struct node));
    return(n);
};

void insertNode() //insertion at the end of the list
{
    struct node *temp, *temp1;

    temp = createNode();
    printf("Enter a number:");
    scanf("%d", &temp->info);

    temp->link = NULL;

    if(START == NULL)
        START = temp;
    else
    {
        temp1 = START;
        while(temp1->link != NULL)
            temp1 = temp1->link;

        temp1->link = temp;
    }
}

void deleteNode() //deletion from first node
{
    struct node *r;

    if(START == NULL)
        printf("List is Empty.");
    else
    {
        r = START;
        START = START->link; //1000-1st node-->2nd node address: 2000
        free(r);
    }
}

void viewList()
{
    struct node *T;

    if(START == NULL)
        printf("List is Empty.");
    else
    {
        T = START;
        while(T != NULL)
        {
            printf("%d ", T->info);
            T = T->link;
        }
    }
}

int main()
{
    int choice;

    while(1)
    {
        printf("\n\n1. Add value to the list.");
        printf("\n2. Delete First Node.");
        printf("\n3. View a list.");
        printf("\n4. Exit.");
        printf("\n\nEnter your Choice:");
        scanf("%d", &choice);

        switch(choice)
        {
        case 1:
            insertNode();
            break;

        case 2:
            deleteNode();
            break;

        case 3:
            viewList();
            break;

        case 4:
            exit(0);

        default:
            printf("Invalid Choice.");
        }
    }

    return 0;
}
