#include <stdio.h>
#include <stdlib.h>

//Defining a node (Data Type)

struct node
{
    struct node *prev;
    int info;
    struct node *next;
};

struct node *START = NULL;

struct node *createNode()
{
    struct node *n;

    n = (struct node *)malloc(sizeof(struct node));

    return(n);
};

//Insert at Start in a list
void insertnodeAtStart()
{
    struct node *temp;

    temp = createNode();

    temp->prev = NULL; //As node insert at start position in a list

    printf("Enter a number:");
    scanf("%d", &temp->info);

    temp->next = START;

    START = temp;
}

//Insert at Last in a list
void insertnodeAtLast()
{
    struct node *temp, *temp1;

    temp = createNode(); //new node

    printf("Enter a number:");
    scanf("%d", &temp->info);

    temp->next = NULL; //assign NULL to temp->next

    if(START == NULL)
    {
        temp->prev = NULL;
        START = temp; //new node assign to START pointer
    }
    else
    {
        temp1 = START;

        while(temp1->next != NULL)
        {
            temp1 = temp1->next;
        }

        temp->prev = temp1;
        temp1->next = temp;
    }

}

//View list in a forward direction
void viewList()
{
    struct node *T;

    if(START == NULL)
        printf("List is Empty.");
    else
    {
        T = START;
        while(T != NULL)
        {
            printf("%d ", T->info);
            T = T->next;
        }
    }
}

int main()
{

    int choice;

    while(1)
    {
        printf("\n\n1. Add value at Start in a list.");
        printf("\n2. Add value at Last in a list.");
        printf("\n3. View List in a Forward Direction.");
        printf("\n5. Exit.");
        printf("\n\nEnter your Choice:");
        scanf("%d", &choice);

        switch(choice)
        {
        case 1:
            insertnodeAtStart();
            break;

        case 2:
            insertnodeAtLast();
            break;

        case 3:
            viewList();
            break;

        case 5:
            exit(0);

        default:
            printf("Invalid Choice.");
        }
    }

    return 0;
}
